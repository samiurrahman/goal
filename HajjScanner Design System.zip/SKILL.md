# SKILL — Designing for HajjScanner

When a user asks for a HajjScanner design (any screen, flow, marketing surface), follow these rules. Read `README.md` for full context; this file is the operational checklist.

## Setup
1. Always link `tokens.css` (or copy its `:root` block) so `--c-primary-*`, `--c-neutral-*`, `--shadow-focus`, etc. resolve.
2. Load Poppins from Google Fonts. No other display family.
3. Use Line Awesome (`la-*`) for content icons; Heroicons-style 1.5px outline SVG for UI controls.

## Defaults to use without thinking
- **Primary brand color**: `rgb(var(--c-primary-700))` `#4338CA` — buttons, brand strokes.
- **Body text**: `rgb(var(--c-neutral-700))`. Headings: `--c-neutral-900`.
- **Borders**: `rgb(var(--c-neutral-200))` 1px. Page bg: `--c-neutral-50`. Cards: white.
- **Buttons**: pill (`border-radius: 9999px`), `padding: 14px 24px`, `font-weight: 500`.
- **Inputs**: 12px radius, `padding: 12px 16px`, focus = primary-500 border + primary-100 ring.
- **Cards**: 24px radius, 1px neutral-200 border, no shadow at rest, `--shadow-card-hover` on hover.
- **Hero search bar**: one giant 9999px-radius white pill containing 4 fields + a 64px primary-700 circular search button. Active field gets `--shadow-focus`.

## Required content patterns
- Currency: `INR 1,85,000` (Indian lakh comma format). Always ISO code prefix, never just `₹` or `$`.
- Distance to holy sites: `220 m to Haram`, `400 m to Masjid Nabawi`. Meters, never feet.
- Duration: `14 nights · 15 days` — both sides.
- Dates: `15 Jun – 28 Jun 2026`.
- Star rating: one decimal. `★ 4.8 (1,284)`.
- Spellings: `Hajj`, `Umrah`, `Haram`, `Masjid Nabawi`, `Makkah`, `Madinah`.

## Things to refuse / avoid
- 🕌 or any emoji. Religious symbols are not decoration.
- "Deals", "exclusive", "limited time", urgency pressure copy.
- Mixing Line Awesome and Heroicons in the same card.
- Inventing new colors. Stay inside the indigo / teal / cool-grey scales.
- Teal (secondary) for anything other than verification & success states.
- Saturated brand color on alert backgrounds — use the `*-bg` semantic tokens instead.

## When something is missing
- **No package imagery**: use `assets/cities/*` for departure-city photos, or a placeholder (`background: rgb(var(--c-primary-50))` with a small Line Awesome icon).
- **No agent logo**: use a 72px circle avatar with two letters in `--c-primary-100` bg / `--c-primary-700` text.
- **No real package data**: use the canonical fixture set — Al-Noor Travels (Bangalore), Madinah Voyages (Delhi), Safa Travels (Mumbai). Prices INR 1,42,000 / 1,85,000 / 2,40,000.

## Reference files
- `README.md` — full design system rationale and content rules.
- `tokens.css` — design tokens. Drop in via `<link>`.
- `ui-kit.html` — every component, copy-paste ready.
- `previews/*.html` — specimen pages (color, type, spacing, brand, components, patterns).
- `assets/logos/` — wordmark and arch icon.
- `assets/cities/` — departure-city photography.
