# HajjScanner Design System

HajjScanner is a Hajj & Umrah package marketplace — connecting pilgrims (primarily from India and the GCC) with verified travel agents that operate Hajj & Umrah tours. Pilgrims search packages by date, departure city, hotel proximity to Haram/Masjid Nabawi, duration, and inclusions; agents publish packages, take inquiries, and respond to bookings. The visual language is calm, premium, and trust-forward — not flashy travel-deals energy. Every component is designed to make a $3k–$15k spiritual purchase feel safe.

## Product context
- **Two audiences**: pilgrims (consumers) and travel agents (B2B sellers).
- **Stack**: Next.js / React + Tailwind + SCSS. Built atop the Chisfis travel-marketplace template, heavily customized.
- **Key surfaces**: home (hero search), package listing grid, package detail (with inclusions, day-by-day itinerary, hotel info), agent profile, agent dashboard, booking inquiry flow, account/profile.

---

## Brand
- **Wordmark**: "HajjScanner" set in a humanist sans (Poppins SemiBold), all letters in primary indigo. A stylized **mosque-arch** sits above the two `j`s — it's the only piece of iconography in the mark and must be preserved.
- **Logo lockups**: full wordmark for headers; arch-only icon for favicon, app icon, and circular avatars.
- **Voice**: warm, respectful, plain. Never "deals", "exclusive offers", "limited time" pressure. Use "guidance", "transparent", "verified", "trusted".

## Content fundamentals

**Copywriting tone**
- Address the user directly ("Find your package", not "Find a package"). Calm imperatives.
- Currency: prefix with the ISO code, never just symbols. `INR 1,85,000` (Indian lakh formatting), `SAR 8,400`, `USD 2,200`. Never abbreviate to "1.8L".
- Dates: `15 Jun 2026` (no commas). For ranges: `15 Jun – 28 Jun 2026`.
- Duration: `14 nights · 15 days`. Always include both because pilgrims book on a "nights at hotel" mental model.
- Distance to holy sites: `220 m to Haram` / `400 m to Masjid Nabawi`. Always meters, no miles, no "feet".
- Use `Hajj`, `Umrah`, `Haram`, `Masjid Nabawi`, `Makkah`, `Madinah` — these exact spellings.
- Never use 🕌 or other emoji. Religious symbols are not decoration.

**Numbers in UI**
- Star ratings: one decimal (`4.8`), never `4.80` or `5.0/5`.
- Review counts: with thousand separators (`1,284 reviews`).
- Prices: bold, primary-900, with currency code on the same line in regular weight at neutral-500 (`INR 1,85,000 / person`). The `/ person` is always lowercase, neutral-500, regular.

## Visual foundations

**Color usage**
- `primary-700 #4338CA` is the brand color and the default state of every primary button. `primary-800` on hover. `primary-900` for headings that need extra weight (rare).
- `primary-600` is for inline links and the iconography on white-card backgrounds.
- `secondary-500 (teal)` is **success-only** — used for "Verified agent" badges, confirmation states, and the booking-success screen.
- `neutral-200` is the canonical border. Never a hairline grey lighter than this on white.
- `--c-warning` (amber) flags Hajj-season urgency and "Popular" tags. Use sparingly — fewer than ~5% of cards in any view.
- Backgrounds: white for cards, `neutral-50` for the page, `primary-900` for the footer, `primary-700→primary-900` gradient on the home hero.

**Type scale**
- Display: Poppins SemiBold (600) for everything h1–h4; Poppins Regular (400) for body.
- Tracking: `-0.02em` on display sizes (h1, hero), `-0.01em` on h2, normal below.
- Never go below 14px in product UI. Hero CTA is 16px.

**Spacing & layout**
- Container max 1280px. Outer page padding: 16/32/128px (`xs / md / 2xl`).
- Section vertical rhythm: 80–96px between sections on desktop, 48–64px on mobile.
- Grid for listing cards: 1col mobile / 2col tablet / 3col desktop, with 32px gap.

**Border radius — distinctively rounded**
- Buttons & filter chips: `rounded-full` (pills).
- Inputs: `0.75rem` (12px).
- Cards: `1.5rem` (24px) — listing cards, agent cards.
- Hero search bar: `9999px` (one giant pill containing the fields).
- Section blocks (FAQ, hero copy block): `2rem`–`3rem`.

**Shadows**
- Default cards rest flat (just `1px solid neutral-200`). On hover they get `--shadow-card-hover`.
- The hero search-bar focused field has the signature `--shadow-focus` (two layered 5%-alpha shadows). This is the most recognizable interaction in the product — preserve it.

## Iconography

- **Line Awesome** is the primary icon family. Always the *line* variant (`la-*`), never solid. Used for nav items, package inclusions (flight, hotel, transport, food), filter facets, footer columns.
- **Heroicons** (outline 24, stroke 1.5) for UI controls: chevrons, close buttons, search, filter sliders, hamburger, share, like.
- One icon family per surface — never mix Line Awesome and Heroicons in the same card.
- Icons inside primary buttons: 20px, currentColor, 8px gap from label.
- "Inclusion" rows (flight included, hotel included, etc) use a 24px Line Awesome icon in `primary-600` on a 40px `primary-50` rounded-full background.

---

## Files in this system
- `tokens.css` — colors, type, radii, shadows, spacing as CSS custom properties. Drop into any HTML file via `<link rel="stylesheet" href="tokens.css">`.
- `assets/logos/` — wordmark (color, mono) and arch-only icon.
- `assets/icons/` — third-party login glyphs (Google, Apple, Facebook, Twitter).
- `assets/images/` — hero banner, "how it works" illustrations, features image.
- `assets/cities/` — departure-city imagery (Bangalore, Delhi, Mumbai, Hyderabad).
- `previews/` — visual specimen pages for the design-system review tab.
- `ui-kit.html` — full component sheet.
