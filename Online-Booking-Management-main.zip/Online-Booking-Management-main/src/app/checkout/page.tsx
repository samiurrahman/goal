import React from "react";
import CheckOutPagePageMain from "./PageMain";

const page = () => {
  return <CheckOutPagePageMain />;
};

export default page;
